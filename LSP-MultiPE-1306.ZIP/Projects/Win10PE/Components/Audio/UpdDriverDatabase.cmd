@echo OFF
SetLocal EnableDelayEdexpansion
Set HKFindKey=%1
Set HKMainOrg=HKEY_LOCAL_MACHINE\PE-Inst-Drivers\DriverDatabase\DriverInfFiles
Set HKMainNew=HKEY_LOCAL_MACHINE\PE-Drivers\DriverDatabase\DriverInfFiles
For /F %%A IN ('Reg Query %HKMainOrg% /K /F %HKFindKey%') Do Call :_RegCopy %%A

Set HKMainOrg=HKEY_LOCAL_MACHINE\PE-Inst-Drivers\DriverDatabase\DriverPackages
Set HKMainNew=HKEY_LOCAL_MACHINE\PE-Drivers\DriverDatabase\DriverPackages
For /F %%A IN ('Reg Query %HKMainOrg% /K /F %HKFindKey%') Do Call :_RegCopy %%A
exit

:_RegCopy
Set HKeyOrg=%1
Call Set HKeyNew=%%HKeyOrg:!HKMainOrg!=!HKMainNew!%%
Reg Query %HKeyOrg% >nul 2>nul
::If Not ErrorLevel 1 Echo Reg Copy %HKeyOrg% %HKeyNew% /S /F
If Not ErrorLevel 1 Reg Copy %HKeyOrg% %HKeyNew% /S /F
Goto :EOF